# TechnicalAnalysisAutomation
Python functions for automating technical analysis. 

Important: 
The pyclustering library does not appear to work with the current version of numpy.

pip install numpy==1.23.1

This numpy version works for me. 
